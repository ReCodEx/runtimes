:- use_module(library(clpb)).
:- use_module(library(clpfd)).
:- use_module(library(clpr)).
